import java.util.Scanner;

public class mainApp {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        boolean running = true;

        while (running) {
            LoginApp.showLoginPage();
            System.out.print("Identifiant : ");
            String username = scanner.nextLine();
            System.out.print("Mot de passe : ");
            String password = scanner.nextLine();

            if (authenticate(username, password)) {
                boolean inMenu = true;
                while (inMenu) {
                    menu.showMenu();
                    System.out.print("Choisissez une option : ");
                    if (scanner.hasNextInt()) {
                        int choice = scanner.nextInt();
                        scanner.nextLine(); // Consume newline

                        switch (choice) {
                            case 1:
                                eleve.showMenu();
                                handleEleveMenu(scanner);
                                break;
                            case 2:
                                prof.showMenu();
                                handleProfMenu(scanner);
                                break;
                            case 3:
                                utilisateur.showMenu();
                                utilisateur.handleUtilisateurMenu(scanner);
                                break;
                            case 0:
                                inMenu = false;
                                break;
                            default:
                                System.out.println("Choix invalide. Veuillez réessayer.");
                        }
                    } else {
                        System.out.println("Veuillez entrer un nombre valide.");
                        scanner.nextLine(); // Consume invalid input
                    }
                }
                running = false;
            } else {
                System.out.println("Identifiant ou mot de passe incorrect. Veuillez réessayer.");
            }
        }

        scanner.close();
    }

    private static boolean authenticate(String username, String password) {
        // Vérifie si l'utilisateur existe dans la liste des utilisateurs
        for (utilisateur utilisateur : utilisateur.getUtilisateurs()) {
            if (utilisateur.getNom().equals(username) && utilisateur.getMotDePasse().equals(password)) {
                return true;
            }
        }
        return false;
    }

    private static void handleEleveMenu(Scanner scanner) {
        boolean inSubMenu = true;
        while (inSubMenu) {
            System.out.print("Choisissez une option : ");
            if (scanner.hasNextInt()) {
                int choice = scanner.nextInt();
                scanner.nextLine(); // Consume newline

                switch (choice) {
                    case 1:
                        System.out.println("Ajouter un élève");
                        break;
                    case 2:
                        System.out.println("Supprimer un élève");
                        break;
                    case 3:
                        System.out.println("Modifier les informations de l'élève");
                        break;
                    case 4:
                        System.out.println("Lister les élèves");
                        break;
                    case 5:
                        System.out.println("Obtenir le dernier élève ajouté");
                        break;
                    case 6:
                        inSubMenu = false;
                        break;
                    case 0:
                        inSubMenu = false;
                        break;
                    default:
                        System.out.println("Choix invalide. Veuillez réessayer.");
                }
            } else {
                System.out.println("Veuillez entrer un nombre valide.");
                scanner.nextLine(); // Consume invalid input
            }
        }
    }

    private static void handleProfMenu(Scanner scanner) {
        boolean inSubMenu = true;
        while (inSubMenu) {
            System.out.print("Choisissez une option : ");
            if (scanner.hasNextInt()) {
                int choice = scanner.nextInt();
                scanner.nextLine(); // Consume newline

                switch (choice) {
                    case 1:
                        System.out.println("Ajouter un professeur");
                        break;
                    case 2:
                        System.out.println("Supprimer un professeur");
                        break;
                    case 3:
                        System.out.println("Modifier les informations du professeur");
                        break;
                    case 4:
                        System.out.println("Lister les professeurs");
                        break;
                    case 5:
                        System.out.println("Obtenir le dernier professeur ajouté");
                        break;
                    case 6:
                        inSubMenu = false;
                        break;
                    case 0:
                        inSubMenu = false;
                        break;
                    default:
                        System.out.println("Choix invalide. Veuillez réessayer.");
                }
            } else {
                System.out.println("Veuillez entrer un nombre valide.");
                scanner.nextLine(); // Consume invalid input
            }
        }
    }
}
