import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class utilisateur {
    private String nom;
    private String motDePasse;

    public utilisateur(String nom, String motDePasse) {
        this.nom = nom;
        this.motDePasse = motDePasse;
    }

    public String getNom() {
        return nom;
    }

    public String getMotDePasse() {
        return motDePasse;
    }

    // Liste des utilisateurs
    private static List<utilisateur> utilisateurs = new ArrayList<>();

    // Initialisation de la liste des utilisateurs avec des utilisateurs prédéfinis
    static {
        utilisateurs.add(new utilisateur("admin", "password"));
        utilisateurs.add(new utilisateur("user1", "user1pass"));
        utilisateurs.add(new utilisateur("user2", "user2pass"));
    }

    // Méthode pour ajouter un utilisateur
    public static void ajouterUtilisateur(String nom, String motDePasse) {
        utilisateurs.add(new utilisateur(nom, motDePasse));
    }

    // Méthode pour supprimer un utilisateur
    public static void supprimerUtilisateur(String nom) {
        utilisateurs.removeIf(utilisateur -> utilisateur.getNom().equals(nom));
    }

    // Méthode pour modifier les informations d'un utilisateur
    public static void modifierUtilisateur(String nom, String nouveauMotDePasse) {
        for (utilisateur utilisateur : utilisateurs) {
            if (utilisateur.getNom().equals(nom)) {
                utilisateur.motDePasse = nouveauMotDePasse;
                break;
            }
        }
    }

    // Méthode pour lister les utilisateurs
    public static void listerUtilisateurs() {
        for (utilisateur utilisateur : utilisateurs) {
            System.out.println("Nom: " + utilisateur.getNom() + ", Mot de passe: " + utilisateur.getMotDePasse());
        }
    }

    // Méthode pour afficher le menu de gestion des utilisateurs
    public static void showMenu() {
        System.out.println("***************************************");
        System.out.println("GESTION DES UTILISATEURS");
        System.out.println("***************************************");
        System.out.println("MENU");
        System.out.println("1: Ajouter un utilisateur");
        System.out.println("2: Supprimer un utilisateur");
        System.out.println("3: Modifier les informations de l'utilisateur");
        System.out.println("4: Lister les utilisateurs");
        System.out.println("5: Retour");
        System.out.println("0: Accueil");
    }

    // Méthode pour gérer les interactions du menu des utilisateurs
    public static void handleUtilisateurMenu(Scanner scanner) {
        boolean inSubMenu = true;
        while (inSubMenu) {
            System.out.print("Choisissez une option : ");
            if (scanner.hasNextInt()) {
                int choice = scanner.nextInt();
                scanner.nextLine(); // Consume newline

                switch (choice) {
                    case 1:
                        System.out.print("Nom de l'utilisateur : ");
                        String nom = scanner.nextLine();
                        System.out.print("Mot de passe : ");
                        String motDePasse = scanner.nextLine();
                        ajouterUtilisateur(nom, motDePasse);
                        break;
                    case 2:
                        System.out.print("Nom de l'utilisateur à supprimer : ");
                        String nomASupprimer = scanner.nextLine();
                        supprimerUtilisateur(nomASupprimer);
                        break;
                    case 3:
                        System.out.print("Nom de l'utilisateur à modifier : ");
                        String nomAModifier = scanner.nextLine();
                        System.out.print("Nouveau mot de passe : ");
                        String nouveauMotDePasse = scanner.nextLine();
                        modifierUtilisateur(nomAModifier, nouveauMotDePasse);
                        break;
                    case 4:
                        listerUtilisateurs();
                        break;
                    case 5:
                        inSubMenu = false;
                        break;
                    case 0:
                        inSubMenu = false;
                        break;
                    default:
                        System.out.println("Choix invalide. Veuillez réessayer.");
                }
            } else {
                System.out.println("Veuillez entrer un nombre valide.");
                scanner.nextLine(); // Consume invalid input
            }
        }
    }

    // Méthode pour obtenir la liste des utilisateurs (pour l'authentification)
    public static List<utilisateur> getUtilisateurs() {
        return utilisateurs;
    }
}
