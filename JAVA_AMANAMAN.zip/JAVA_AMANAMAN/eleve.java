import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class eleve {
    private String nom;
    private String motDePasse;

    public eleve(String nom, String motDePasse) {
        this.nom = nom;
        this.motDePasse = motDePasse;
    }

    public String getNom() {
        return nom;
    }

    public String getMotDePasse() {
        return motDePasse;
    }

    // Liste des eleves
    private static List<eleve> eleves = new ArrayList<>();

    // Initialisation de la liste des eleves avec des eleves prédéfinis
    static {
        eleves.add(new eleve("admin", "password"));
        eleves.add(new eleve("user1", "user1pass"));
        eleves.add(new eleve("user2", "user2pass"));
    }

    // Méthode pour ajouter un eleve
    public static void ajoutereleve(String nom, String motDePasse) {
        eleves.add(new eleve(nom, motDePasse));
    }

    // Méthode pour supprimer un eleve
    public static void supprimereleve(String nom) {
        eleves.removeIf(eleve -> eleve.getNom().equals(nom));
    }

    // Méthode pour modifier les informations d'un eleve
    public static void modifiereleve(String nom, String nouveauMotDePasse) {
        for (eleve eleve : eleves) {
            if (eleve.getNom().equals(nom)) {
                eleve.motDePasse = nouveauMotDePasse;
                break;
            }
        }
    }

    // Méthode pour lister les eleves
    public static void listereleves() {
        for (eleve eleve : eleves) {
            System.out.println("Nom: " + eleve.getNom() + ", Mot de passe: " + eleve.getMotDePasse());
        }
    }

    // Méthode pour afficher le menu de gestion des eleves
    public static void showMenu() {
        System.out.println("***************************************");
        System.out.println("GESTION DES eleveS");
        System.out.println("***************************************");
        System.out.println("MENU");
        System.out.println("1: Ajouter un eleve");
        System.out.println("2: Supprimer un eleve");
        System.out.println("3: Modifier les informations de l'eleve");
        System.out.println("4: Lister les eleves");
        System.out.println("5: Retour");
        System.out.println("0: Accueil");
    }

    // Méthode pour gérer les interactions du menu des eleves
    public static void handleeleveMenu(Scanner scanner) {
        boolean inSubMenu = true;
        while (inSubMenu) {
            System.out.print("Choisissez une option : ");
            if (scanner.hasNextInt()) {
                int choice = scanner.nextInt();
                scanner.nextLine(); // Consume newline

                switch (choice) {
                    case 1:
                        System.out.print("Nom de l'eleve : ");
                        String nom = scanner.nextLine();
                        System.out.print("Mot de passe : ");
                        String motDePasse = scanner.nextLine();
                        ajoutereleve(nom, motDePasse);
                        break;
                    case 2:
                        System.out.print("Nom de l'eleve à supprimer : ");
                        String nomASupprimer = scanner.nextLine();
                        supprimereleve(nomASupprimer);
                        break;
                    case 3:
                        System.out.print("Nom de l'eleve à modifier : ");
                        String nomAModifier = scanner.nextLine();
                        System.out.print("Nouveau mot de passe : ");
                        String nouveauMotDePasse = scanner.nextLine();
                        modifiereleve(nomAModifier, nouveauMotDePasse);
                        break;
                    case 4:
                        listereleves();
                        break;
                    case 5:
                        inSubMenu = false;
                        break;
                    case 0:
                        inSubMenu = false;
                        break;
                    default:
                        System.out.println("Choix invalide. Veuillez réessayer.");
                }
            } else {
                System.out.println("Veuillez entrer un nombre valide.");
                scanner.nextLine(); // Consume invalid input
            }
        }
    }

    // Méthode pour obtenir la liste des eleves (pour l'authentification)
    public static List<eleve> geteleves() {
        return eleves;
    }
}
