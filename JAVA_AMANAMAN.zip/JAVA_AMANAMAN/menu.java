public class menu {
    public static void showMenu() {
        System.out.println("***************************************");
        System.out.println("BIENVENUE DANS L'APPLICATION ETAB v1.1");
        System.out.println("***************************************");
        System.out.println("MENU");
        System.out.println("1: Gestion des élèves");
        System.out.println("2: Gestion des professeurs");
        System.out.println("3: Gestion des utilisateurs");
        System.out.println("0: Quitter");
    }
}
