public class LoginApp {
    public static void showLoginPage() {
        System.out.println("***************************************");
        System.out.println("BIENVENUE DANS L'APPLICATION ETAB v1.1");
        System.out.println("***************************************");
        System.out.println("CONNEXION");
    }
}
