import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class prof {
    private String nom;
    private String motDePasse;

    public prof(String nom, String motDePasse) {
        this.nom = nom;
        this.motDePasse = motDePasse;
    }

    public String getNom() {
        return nom;
    }

    public String getMotDePasse() {
        return motDePasse;
    }

    // Liste des profs
    private static List<prof> profs = new ArrayList<>();

    // Initialisation de la liste des profs avec des profs prédéfinis
    static {
        profs.add(new prof("admin", "password"));
        profs.add(new prof("user1", "user1pass"));
        profs.add(new prof("user2", "user2pass"));
    }

    // Méthode pour ajouter un prof
    public static void ajouterprof(String nom, String motDePasse) {
        profs.add(new prof(nom, motDePasse));
    }

    // Méthode pour supprimer un prof
    public static void supprimerprof(String nom) {
        profs.removeIf(prof -> prof.getNom().equals(nom));
    }

    // Méthode pour modifier les informations d'un prof
    public static void modifierprof(String nom, String nouveauMotDePasse) {
        for (prof prof : profs) {
            if (prof.getNom().equals(nom)) {
                prof.motDePasse = nouveauMotDePasse;
                break;
            }
        }
    }

    // Méthode pour lister les profs
    public static void listerprofs() {
        for (prof prof : profs) {
            System.out.println("Nom: " + prof.getNom() + ", Mot de passe: " + prof.getMotDePasse());
        }
    }

    // Méthode pour afficher le menu de gestion des profs
    public static void showMenu() {
        System.out.println("***************************************");
        System.out.println("GESTION DES profS");
        System.out.println("***************************************");
        System.out.println("MENU");
        System.out.println("1: Ajouter un prof");
        System.out.println("2: Supprimer un prof");
        System.out.println("3: Modifier les informations de l'prof");
        System.out.println("4: Lister les profs");
        System.out.println("5: Retour");
        System.out.println("0: Accueil");
    }

    // Méthode pour gérer les interactions du menu des profs
    public static void handleprofMenu(Scanner scanner) {
        boolean inSubMenu = true;
        while (inSubMenu) {
            System.out.print("Choisissez une option : ");
            if (scanner.hasNextInt()) {
                int choice = scanner.nextInt();
                scanner.nextLine(); // Consume newline

                switch (choice) {
                    case 1:
                        System.out.print("Nom de l'prof : ");
                        String nom = scanner.nextLine();
                        System.out.print("Mot de passe : ");
                        String motDePasse = scanner.nextLine();
                        ajouterprof(nom, motDePasse);
                        break;
                    case 2:
                        System.out.print("Nom de l'prof à supprimer : ");
                        String nomASupprimer = scanner.nextLine();
                        supprimerprof(nomASupprimer);
                        break;
                    case 3:
                        System.out.print("Nom de l'prof à modifier : ");
                        String nomAModifier = scanner.nextLine();
                        System.out.print("Nouveau mot de passe : ");
                        String nouveauMotDePasse = scanner.nextLine();
                        modifierprof(nomAModifier, nouveauMotDePasse);
                        break;
                    case 4:
                        listerprofs();
                        break;
                    case 5:
                        inSubMenu = false;
                        break;
                    case 0:
                        inSubMenu = false;
                        break;
                    default:
                        System.out.println("Choix invalide. Veuillez réessayer.");
                }
            } else {
                System.out.println("Veuillez entrer un nombre valide.");
                scanner.nextLine(); // Consume invalid input
            }
        }
    }

    // Méthode pour obtenir la liste des profs (pour l'authentification)
    public static List<prof> getprofs() {
        return profs;
    }
}
